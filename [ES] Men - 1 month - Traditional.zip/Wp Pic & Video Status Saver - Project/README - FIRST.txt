
**************** README **************************


Note: The Google Play Store prefers the APP BUNDLE format then APK.


--------- KEYSTORE INFORMATION ---------------

Warning: Keep the "key.properties" info and wpstatusaver_keystore.jks file private; 
don’t check them into public source control like Github etc..

key.properties info located in app source code: {app dir}/android/key.properties
------------------------------------------------
storePassword=SG@2020
keyPassword=SG@2020
keyAlias=key
storeFile=C:/PATH/TO/wpstatusaver_keystore.jks
-------------------------------------------------